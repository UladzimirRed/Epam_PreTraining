package entity;

public enum BookType {
    PAPER_BOOK, E_BOOK
}
