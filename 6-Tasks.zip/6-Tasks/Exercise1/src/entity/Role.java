package entity;

public enum  Role {
    USER, ADMIN
}
